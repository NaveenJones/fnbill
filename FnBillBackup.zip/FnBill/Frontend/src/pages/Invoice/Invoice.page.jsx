import { useState } from "react"

function InvoicePage() {

    return (
        <>
                <div className="text-sm text-center  pl-10">
                Working on it...! 
            </div>
        </>
    )
}

export default InvoicePage;
