import LoginForm from "../../forms/Login/Login.form";

function LoginPage() {
  return (
    <div className="w-full flex justify-center">
      <LoginForm />
    </div>
  );
}

export default LoginPage;
