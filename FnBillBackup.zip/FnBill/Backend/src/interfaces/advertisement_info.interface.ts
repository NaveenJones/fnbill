export interface advertisementInfoInterface {
  ad_name: string;
  ad_file: string;
}
