export enum CustomInvoiceStateEnum {
  Mutable = 0, // Unpaid
  Immutable = 1, // Unpaid
  Paid = 2,
}
