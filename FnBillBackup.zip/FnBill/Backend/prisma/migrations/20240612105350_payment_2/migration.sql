-- AlterTable
ALTER TABLE "CustomInvoice" ADD COLUMN     "paid_on" TIMESTAMP(3);
